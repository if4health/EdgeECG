class MinHeapNode:
    def __init__(self, data, freq, order):
        self.data = data
        self.freq = freq
        self.order = order  # Adicionando ordem de inserção como critério de desempate
        self.left = None
        self.right = None


class MinHeap:
    def __init__(self):
        self.array = []
        self.size = 0

    def swap_nodes(self, i, j):
        self.array[i], self.array[j] = self.array[j], self.array[i]

    def min_heapify(self, idx):
        smallest = idx
        left = 2 * idx + 1
        right = 2 * idx + 2

        if left < self.size and self.compare_nodes(left, smallest):
            smallest = left
        if right < self.size and self.compare_nodes(right, smallest):
            smallest = right
        if smallest != idx:
            self.swap_nodes(idx, smallest)
            self.min_heapify(smallest)

    def compare_nodes(self, idx1, idx2):
        """Critério de desempate para frequência igual."""
        if self.array[idx1].freq == self.array[idx2].freq:
            return self.array[idx1].order < self.array[idx2].order
        return self.array[idx1].freq < self.array[idx2].freq

    def extract_min(self):
        root = self.array[0]
        self.array[0] = self.array[self.size - 1]
        self.size -= 1
        self.array.pop()
        self.min_heapify(0)
        return root

    def insert(self, node):
        self.size += 1
        self.array.append(node)
        i = self.size - 1
        while i > 0 and self.compare_nodes(i, (i - 1) // 2):
            self.swap_nodes(i, (i - 1) // 2)
            i = (i - 1) // 2


def create_and_build_min_heap(data, freq):
    min_heap = MinHeap()
    for order, (val, frq) in enumerate(zip(data, freq)):
        min_heap.array.append(MinHeapNode(val, frq, order))
    min_heap.size = len(data)
    for i in range((min_heap.size - 2) // 2, -1, -1):
        min_heap.min_heapify(i)
    return min_heap


def build_huffman_tree(data, freq):
    min_heap = create_and_build_min_heap(data, freq)
    order = len(data)  # Para novas inserções, a ordem começa após o último índice original
    while min_heap.size > 1:
        left = min_heap.extract_min()
        right = min_heap.extract_min()
        top = MinHeapNode('$', left.freq + right.freq, order)
        top.left = left
        top.right = right
        min_heap.insert(top)
        order += 1
    return min_heap.extract_min()


def store_codes(root, code_str, codes):
    if root is None:
        return
    if root.data != '$':
        codes[root.data] = code_str
    store_codes(root.left, code_str + '0', codes)
    store_codes(root.right, code_str + '1', codes)


def calculate_frequencies(data):
    freq = {}
    for val in data:
        rounded_val = round(val, 3)  # Arredondar para 3 casas decimais
        if rounded_val in freq:
            freq[rounded_val] += 1
        else:
            freq[rounded_val] = 1
    unique_values = list(freq.keys())
    frequencies = list(freq.values())
    return unique_values, frequencies


def huffman_encoding(data):
    unique_values, frequencies = calculate_frequencies(data)
    root = build_huffman_tree(unique_values, frequencies)

    codes = {}
    store_codes(root, '', codes)

    encoded_string = ''.join(codes[round(val, 3)] for val in data)
    return codes, encoded_string, root


def huffman_decoding(encoded_string, root):
    decoded_values = []
    current = root
    for bit in encoded_string:
        current = current.left if bit == '0' else current.right
        if current.left is None and current.right is None:
            decoded_values.append(current.data)
            current = root
    return decoded_values


if __name__ == "__main__":
 
    original_values = [0.010000, -0.080000, -0.210000, -0.170000, -0.180000, -0.290000, -0.340000, -0.370000, -0.370000, -0.790000, 0.760000, -0.030000, -0.470000, -0.490000, -0.520000, -0.500000, -0.520000, -0.520000, -0.570000, -0.560000, -0.610000, -0.700000, -0.820000, -0.900000, -0.840000, -0.650000, -0.460000, -0.450000, -0.440000, -0.470000, -0.500000, -0.550000, -0.580000, -0.590000, -0.610000, -0.620000, -0.610000, -0.600000, -0.640000, -0.560000, -0.510000, -0.520000, -0.590000, -0.650000, -0.650000, 0.050000, -0.010000, -0.020000, 0.030000, 0.010000, 0.010000, 0.010000, -0.030000, 0.050000, -0.260000, 0.670000, -0.110000, -0.020000, -0.000000, 0.020000, -0.010000, 0.000000, 0.020000, -0.010000, -0.010000, -0.000000, -0.010000, -0.010000, -0.030000, -0.000000, 0.010000, 0.030000, 0.000000, 0.000000, 0.030000, -0.010000, -0.030000, 0.020000, -0.020000, -0.010000, 0.010000, -0.020000, -0.000000, -0.010000, 0.010000, 0.000000, -0.010000, 0.010000, -0.000000, 0.040000, 0.040000, -0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, 0.010000, 0.010000, -0.040000, 0.010000, 0.010000, -0.020000, -0.000000, 0.020000, -0.020000, 0.010000, -0.070000, -0.050000, 0.330000, -0.270000, -0.010000, -0.010000, 0.010000, -0.020000, 0.010000, 0.010000, -0.010000, 0.010000, 0.010000, -0.020000, 0.000000, -0.000000, -0.010000, -0.010000, 0.020000, -0.020000, -0.000000, 0.020000, -0.020000, 0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, -0.000000, 0.010000, -0.020000, 0.010000, 0.020000, -0.010000, 0.010000, -0.000000, -0.010000, 0.000000, 0.010000, -0.030000, 0.020000, -0.000000, -0.020000, -0.010000, 0.010000, -0.020000, 0.020000, 0.000000, -0.000000, -0.010000, 0.000000, -0.010000, 0.010000, 0.010000, -0.020000, 0.010000, 0.000000, -0.020000, 0.010000, 0.010000, -0.020000, 0.000000, 0.010000, -0.010000, -0.000000, 0.020000, -0.030000, 0.000000, 0.010000, -0.020000, 0.010000, 0.020000, -0.020000, 0.000000, 0.000000, 0.000000, -0.010000, -0.000000, 0.000000, -0.000000, 0.000000, -0.000000, 0.010000, -0.010000, -0.010000, -0.000000, -0.000000, 0.000000, -0.000000, -0.010000, 0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.010000, 0.000000, -0.000000, -0.000000, -0.000000, 0.000000, 0.010000, -0.000000, 0.010000, -0.020000, -0.030000, 0.010000, -0.000000, -0.010000, 0.030000, 0.100000, -0.070000, -0.040000, 0.020000, 0.000000, 0.020000, -0.010000, 0.000000, 0.010000, -0.000000, 0.000000, 0.010000, -0.010000, -0.000000, 0.010000, -0.010000, 0.010000, -0.000000, -0.010000, -0.000000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, -0.010000, 0.010000, -0.010000, 0.010000, 0.000000, 0.000000, -0.000000, -0.010000, -0.010000, 0.010000, 0.000000, -0.010000, 0.010000, -0.000000, -0.000000, 0.000000, 0.000000, -0.010000, -0.000000, -0.000000, -0.000000, -0.010000, 0.010000, -0.000000, -0.000000, 0.010000, -0.010000, -0.000000, -0.010000, -0.010000, -0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.000000, 0.000000, 0.010000, -0.000000, 0.000000, -0.010000, -0.010000, 0.000000, 0.010000, 0.000000, 0.000000, 0.010000, -0.010000, -0.000000, 0.010000, 0.000000, -0.000000, 0.010000, -0.000000, 0.000000, 0.000000, -0.010000, -0.000000, -0.000000, -0.010000, -0.000000, -0.000000, -0.000000, -0.010000, -0.000000, -0.010000, 0.010000, -0.000000, -0.010000, 0.010000, -0.000000, -0.000000, -0.010000, 0.000000, -0.010000, -0.010000, 0.000000, 0.000000, 0.000000, 0.000000, -0.000000, 0.000000, -0.000000, 0.010000, -0.010000, 0.010000, 0.000000, -0.010000, 0.000000, -0.010000, 0.000000, -0.000000, -0.010000, 0.010000, 0.000000, -0.000000, 0.000000, 0.010000, -0.010000, -0.000000, -0.000000, -0.010000, -0.000000, 0.000000, -0.010000, -0.010000, 0.000000, -0.000000, -0.010000, 0.000000, 0.000000, 0.010000, 0.000000, -0.000000, 0.000000, 0.000000, -0.030000]

    # Codificação
    codes, encoded_string, root = huffman_encoding(original_values)

    print("Valores e seus Códigos Huffman:")
    for val, code in sorted(codes.items(), key=lambda x: x[0]):
        print(f"{val:.3f}: {code}")

    print("\nCodificação:")
    print(encoded_string)

    # Decodificação
    decoded_values = huffman_decoding(encoded_string, root)
    print("\nDecodificação:")
    print(' '.join(f"{val:.3f}" for val in decoded_values))
    print("\nPrograma concluído.")

   
    