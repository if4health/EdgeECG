import heapq
from collections import defaultdict

# Para mapear cada valor float para o seu valor Huffman
codes = {}

# Para armazenar a frequência de cada valor float no vetor de entrada
freq = defaultdict(int)

# Um nó da árvore de Huffman
class MinHeapNode:
		def __init__(self, data, freq):
				self.left = None
				self.right = None
				self.data = data
				self.freq = freq

		def __lt__(self, other):
				return self.freq < other.freq

# Função utilitária para imprimir valores float junto com
# seus valores Huffman
def printCodes(root, code_str):
		if root is None:
				return
		if root.data != '$':
				print(root.data, ":", code_str)
		printCodes(root.left, code_str + "0")
		printCodes(root.right, code_str + "1")

# Função utilitária para armazenar valores float junto com
# seus valores Huffman em um dicionário
def storeCodes(root, code_str):
		if root is None:
				return
		if root.data != '$':
				codes[root.data] = code_str
		storeCodes(root.left, code_str + "0")
		storeCodes(root.right, code_str + "1")

# Função para construir a árvore de Huffman
def HuffmanCodes(size):
		global minHeap
		for key in freq:
				minHeap.append(MinHeapNode(key, freq[key]))
		heapq.heapify(minHeap)
		while len(minHeap) != 1:
				left = heapq.heappop(minHeap)
				right = heapq.heappop(minHeap)
				top = MinHeapNode('$', left.freq + right.freq)
				top.left = left
				top.right = right
				heapq.heappush(minHeap, top)
		storeCodes(minHeap[0], "")

# Função para calcular a frequência de cada valor float
def calcFreq(values, n):
		for i in range(n):
				freq[values[i]] += 1

# Função para decodificar a string Huffman
def decode_file(root, s):
		ans = []
		curr = root
		n = len(s)
		for i in range(n):
				if s[i] == '0':
						curr = curr.left
				else:
						curr = curr.right

				# Nó folha 
				if curr.left is None and curr.right is None:
						ans.append(curr.data)
						curr = root
		return ans

# Código principal
if __name__ == "__main__":
		minHeap = []
		# Definindo o vetor de valores float
		values = [ -0.065, -0.080, -0.085, -0.090, -0.065, -0.080, -0.065, -0.110, -0.065, -0.080, -0.085, -0.090]

		encodedString, decodedString = "", []

		# Calcula a frequência dos valores
		calcFreq(values, len(values))

		# Constrói a árvore de Huffman
		HuffmanCodes(len(values))

		print("Valores com suas Frequências:")
		for key in sorted(codes):
				print(key, codes[key])

		# Codifica os valores
		for value in values:
				encodedString += codes[value]

		print("\nDados codificados com Huffman:")
		print(encodedString)

		# Decodifica os dados
		decodedValues = decode_file(minHeap[0], encodedString)
		print("\nDados decodificados com Huffman:")
		print(decodedValues)



# Comparação de compressão
original_size_bits = len(values) * 32  # Cada float ocupa 32 bits
compressed_size_bits = len(encodedString)

# Taxa de compressão e fator de compressão
compression_ratio = compressed_size_bits / original_size_bits
compression_factor = original_size_bits / compressed_size_bits

print("\nComparação de Compressão:")
print(f"Tamanho Original (bits): {original_size_bits}")
print(f"Tamanho Comprimido (bits): {compressed_size_bits}")
print(f"Taxa de Compressão: {compression_ratio:.2%}")
print(f"Fator de Compressão: {compression_factor:.2f}")