#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_CODE_LEN 32
#define MAX_VALUES 128

typedef struct MinHeapNode {
    float data;
    unsigned freq;
    struct MinHeapNode *left, *right;
} MinHeapNode;

typedef struct {
    MinHeapNode* array[MAX_VALUES];
    int size;
    int insertion_order[MAX_VALUES]; // Ordem de inserção para critério de desempate
} MinHeap;

// Função para criar um novo nó
MinHeapNode* newNode(float data, unsigned freq) {
    MinHeapNode* temp = (MinHeapNode*)malloc(sizeof(MinHeapNode));
    temp->data = data;
    temp->freq = freq;
    temp->left = temp->right = NULL;
    return temp;
}

// Função para trocar dois nós no heap
void swapNodes(MinHeapNode** a, MinHeapNode** b, int* order_a, int* order_b) {
    MinHeapNode* tempNode = *a;
    *a = *b;
    *b = tempNode;

    int tempOrder = *order_a;
    *order_a = *order_b;
    *order_b = tempOrder;
}

// Critério de comparação de dois nós do heap
int compareNodes(MinHeap* heap, int idx1, int idx2) {
    MinHeapNode* node1 = heap->array[idx1];
    MinHeapNode* node2 = heap->array[idx2];

    if (node1->freq == node2->freq) {
        return heap->insertion_order[idx1] < heap->insertion_order[idx2];
    }
    return node1->freq < node2->freq;
}

// MinHeapify
void minHeapify(MinHeap* heap, int idx) {
    int smallest = idx;
    int left = 2 * idx + 1;
    int right = 2 * idx + 2;

    if (left < heap->size && compareNodes(heap, left, smallest)) {
        smallest = left;
    }
    if (right < heap->size && compareNodes(heap, right, smallest)) {
        smallest = right;
    }
    if (smallest != idx) {
        swapNodes(&heap->array[smallest], &heap->array[idx],
                  &heap->insertion_order[smallest], &heap->insertion_order[idx]);
        minHeapify(heap, smallest);
    }
}

// Extração do menor nó
MinHeapNode* extractMin(MinHeap* heap) {
    MinHeapNode* root = heap->array[0];
    heap->array[0] = heap->array[heap->size - 1];
    heap->insertion_order[0] = heap->insertion_order[heap->size - 1];
    heap->size--;
    minHeapify(heap, 0);
    return root;
}

// Inserção no heap
void insertMinHeap(MinHeap* heap, MinHeapNode* node, int order) {
    int i = heap->size++;
    heap->array[i] = node;
    heap->insertion_order[i] = order;

    while (i && compareNodes(heap, i, (i - 1) / 2)) {
        swapNodes(&heap->array[i], &heap->array[(i - 1) / 2],
                  &heap->insertion_order[i], &heap->insertion_order[(i - 1) / 2]);
        i = (i - 1) / 2;
    }
}

// Criação do heap
MinHeap* createAndBuildMinHeap(float data[], unsigned freq[], int size) {
    MinHeap* heap = (MinHeap*)malloc(sizeof(MinHeap));
    heap->size = 0;

    for (int i = 0; i < size; i++) {
        insertMinHeap(heap, newNode(data[i], freq[i]), i);
    }
    return heap;
}

// Construção da árvore de Huffman
MinHeapNode* buildHuffmanTree(float data[], unsigned freq[], int size) {
    MinHeap* heap = createAndBuildMinHeap(data, freq, size);

    while (heap->size > 1) {
        MinHeapNode* left = extractMin(heap);
        MinHeapNode* right = extractMin(heap);

        MinHeapNode* top = newNode('$', left->freq + right->freq);
        top->left = left;
        top->right = right;

        insertMinHeap(heap, top, size++); // Nós internos têm ordem crescente
    }
    return extractMin(heap);
}

// Armazena os códigos de Huffman
void storeCodes(MinHeapNode* root, char* code, int top, char codes[MAX_VALUES][MAX_CODE_LEN], float values[MAX_VALUES], int* index) {
    if (root->left) {
        code[top] = '0';
        storeCodes(root->left, code, top + 1, codes, values, index);
    }

    if (root->right) {
        code[top] = '1';
        storeCodes(root->right, code, top + 1, codes, values, index);
    }

    if (!root->left && !root->right) {
        code[top] = '\0';
        values[*index] = root->data;
        strcpy(codes[*index], code);
        (*index)++;
    }
}

// Calcula as frequências dos valores
int calculateFrequencies(float data[], int n, float unique[], unsigned freq[]) {
    int count = 0;
    for (int i = 0; i < n; i++) {
        int found = 0;
        for (int j = 0; j < count; j++) {
            if (fabs(data[i] - unique[j]) < 1e-5) {
                freq[j]++;
                found = 1;
                break;
            }
        }
        if (!found) {
            unique[count] = data[i];
            freq[count++] = 1;
        }
    }
    return count;
}

// Função principal
int main() {
    float originalValues[] = {0.010000, -0.080000, -0.210000, -0.170000, -0.180000, -0.290000, -0.340000, -0.370000, -0.370000, -0.790000, 0.760000, -0.030000, -0.470000, -0.490000, -0.520000, -0.500000, -0.520000, -0.520000, -0.570000, -0.560000, -0.610000, -0.700000, -0.820000, -0.900000, -0.840000, -0.650000, -0.460000, -0.450000, -0.440000, -0.470000, -0.500000, -0.550000, -0.580000, -0.590000, -0.610000, -0.620000, -0.610000, -0.600000, -0.640000, -0.560000, -0.510000, -0.520000, -0.590000, -0.650000, -0.650000, 0.050000, -0.010000, -0.020000, 0.030000, 0.010000, 0.010000, 0.010000, -0.030000, 0.050000, -0.260000, 0.670000, -0.110000, -0.020000, -0.000000, 0.020000, -0.010000, 0.000000, 0.020000, -0.010000, -0.010000, -0.000000, -0.010000, -0.010000, -0.030000, -0.000000, 0.010000, 0.030000, 0.000000, 0.000000, 0.030000, -0.010000, -0.030000, 0.020000, -0.020000, -0.010000, 0.010000, -0.020000, -0.000000, -0.010000, 0.010000, 0.000000, -0.010000, 0.010000, -0.000000, 0.040000, 0.040000, -0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, 0.010000, 0.010000, -0.040000, 0.010000, 0.010000, -0.020000, -0.000000, 0.020000, -0.020000, 0.010000, -0.070000, -0.050000, 0.330000, -0.270000, -0.010000, -0.010000, 0.010000, -0.020000, 0.010000, 0.010000, -0.010000, 0.010000, 0.010000, -0.020000, 0.000000, -0.000000, -0.010000, -0.010000, 0.020000, -0.020000, -0.000000, 0.020000, -0.020000, 0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, -0.000000, 0.010000, -0.020000, 0.010000, 0.020000, -0.010000, 0.010000, -0.000000, -0.010000, 0.000000, 0.010000, -0.030000, 0.020000, -0.000000, -0.020000, -0.010000, 0.010000, -0.020000, 0.020000, 0.000000, -0.000000, -0.010000, 0.000000, -0.010000, 0.010000, 0.010000, -0.020000, 0.010000, 0.000000, -0.020000, 0.010000, 0.010000, -0.020000, 0.000000, 0.010000, -0.010000, -0.000000, 0.020000, -0.030000, 0.000000, 0.010000, -0.020000, 0.010000, 0.020000, -0.020000, 0.000000, 0.000000, 0.000000, -0.010000, -0.000000, 0.000000, -0.000000, 0.000000, -0.000000, 0.010000, -0.010000, -0.010000, -0.000000, -0.000000, 0.000000, -0.000000, -0.010000, 0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.010000, 0.000000, -0.000000, -0.000000, -0.000000, 0.000000, 0.010000, -0.000000, 0.010000, -0.020000, -0.030000, 0.010000, -0.000000, -0.010000, 0.030000, 0.100000, -0.070000, -0.040000, 0.020000, 0.000000, 0.020000, -0.010000, 0.000000, 0.010000, -0.000000, 0.000000, 0.010000, -0.010000, -0.000000, 0.010000, -0.010000, 0.010000, -0.000000, -0.010000, -0.000000, 0.010000, -0.010000, -0.000000, 0.010000, -0.020000, -0.010000, 0.010000, -0.010000, 0.010000, 0.000000, 0.000000, -0.000000, -0.010000, -0.010000, 0.010000, 0.000000, -0.010000, 0.010000, -0.000000, -0.000000, 0.000000, 0.000000, -0.010000, -0.000000, -0.000000, -0.000000, -0.010000, 0.010000, -0.000000, -0.000000, 0.010000, -0.010000, -0.000000, -0.010000, -0.010000, -0.010000, 0.010000, -0.010000, -0.000000, 0.010000, -0.000000, 0.000000, 0.010000, -0.000000, 0.000000, -0.010000, -0.010000, 0.000000, 0.010000, 0.000000, 0.000000, 0.010000, -0.010000, -0.000000, 0.010000, 0.000000, -0.000000, 0.010000, -0.000000, 0.000000, 0.000000, -0.010000, -0.000000, -0.000000, -0.010000, -0.000000, -0.000000, -0.000000, -0.010000, -0.000000, -0.010000, 0.010000, -0.000000, -0.010000, 0.010000, -0.000000, -0.000000, -0.010000, 0.000000, -0.010000, -0.010000, 0.000000, 0.000000, 0.000000, 0.000000, -0.000000, 0.000000, -0.000000, 0.010000, -0.010000, 0.010000, 0.000000, -0.010000, 0.000000, -0.010000, 0.000000, -0.000000, -0.010000, 0.010000, 0.000000, -0.000000, 0.000000, 0.010000, -0.010000, -0.000000, -0.000000, -0.010000, -0.000000, 0.000000, -0.010000, -0.010000, 0.000000, -0.000000, -0.010000, 0.000000, 0.000000, 0.010000, 0.000000, -0.000000, 0.000000, 0.000000, -0.030000};
    int n = sizeof(originalValues) / sizeof(originalValues[0]);

    float uniqueValues[MAX_VALUES];
    unsigned freq[MAX_VALUES];
    memset(freq, 0, sizeof(freq));

    int size = calculateFrequencies(originalValues, n, uniqueValues, freq);

    MinHeapNode* root = buildHuffmanTree(uniqueValues, freq, size);

    char codes[MAX_VALUES][MAX_CODE_LEN];
    char code[MAX_CODE_LEN];
    float values[MAX_VALUES];
    int index = 0;

    storeCodes(root, code, 0, codes, values, &index);

    printf("Valores e seus Códigos Huffman:\n");
    for (int i = 0; i < index; i++) {
        printf("%.3f: %s\n", values[i], codes[i]);
    }

    printf("\nCodificação:\n");
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < index; j++) {
            if (fabs(originalValues[i] - values[j]) < 1e-5) {
                printf("%s", codes[j]);
                break;
            }
        }
    }
    printf("\n\nPrograma concluído.\n");
    return 0;
}

